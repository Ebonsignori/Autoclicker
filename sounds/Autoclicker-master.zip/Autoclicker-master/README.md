# Autoclicker
Auto clicks and alternates between 2 - 5 selected screenshots
